package automation.BDDFramework.testcases;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import automation.BDDFramework.assertions.Compare;
import automation.BDDFramework.base.DriverInstance;
import automation.BDDFramework.pages.HomePage;
import cucumber.api.java.en.*;

public class Steps {
	
	WebDriver driver;
	HomePage home; // global object
	
	@Given("^User is on HomePage$")
	public void user_is_on_HomePage() throws Throwable {
		DriverInstance driverInstance = new DriverInstance();
		driver = driverInstance.createDriverInstance();
	
	}

	@When("^User enters a query$")
	public void user_enters_a_query() throws Throwable {
		
		home = new HomePage(driver);
		home.enterSearchQuery("Books");
	   
	}

	@When("^clicks on the search button$")
	public void clicks_on_the_search_button() throws Throwable {
		Thread.sleep(5000);
		home.clickSearchbutton();
	}

	@When("^clicks on the sign in link on the homepage$")
	public void clicks_on_the_sign_in_link_on_the_homepage() throws Throwable {
		
		home.clickSignInLink();
	
	}

	@When("^enters an invalid email address$")
	public void enters_an_invalid_email_address() throws Throwable {
		
		Thread.sleep(5000);
		home.enterEmail("lala@mailinator.com");
	
	}

	@When("^enters a invalid password$")
	public void enters_a_invalid_password() throws Throwable {
		
		home.enterPassword("123");
	
	}

	@When("^User clicks on the sign in submit button$")
	public void user_clicks_on_the_sign_in_submit_button() throws Throwable {
		
		home.clickSignInBtn();
	 
	}

	@Then("^User is not logged in successfully$")
	public void user_is_not_logged_in_successfully() throws Throwable {
		
	Assert.assertTrue(Compare.validatePageURL(driver, "https://www.amazon.co.uk/ap/signin"));
		
		Compare.validateElementExists(driver, "authorisationMsg_id");
	   
	}

}
