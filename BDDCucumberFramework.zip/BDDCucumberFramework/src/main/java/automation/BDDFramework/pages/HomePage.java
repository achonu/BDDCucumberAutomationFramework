package automation.BDDFramework.pages;

import java.util.ResourceBundle;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
	
	ResourceBundle element; // public variable so all methods can access it
	WebDriver driver;
	
	public HomePage(WebDriver driver) { // constructor
		
		this.driver=driver; //passing local variable to global
		element = ResourceBundle.getBundle("elements"); //no need to repeat it in every method
	}
	
	
	public void enterSearchQuery(String query) {

		driver.findElement(By.id(element.getString("searchbox_id"))).sendKeys(query);

	}
	
	public void clickSearchbutton() {
		
		driver.findElement(By.xpath(element.getString("searchboxBtn_xpath"))).click();
		
	}
	
	public void clickSignInLink() {
		
		driver.findElement(By.id(element.getString("signInLink_id"))).click();
	}
	
	public void enterEmail(String email) {
		
		
		driver.findElement(By.id(element.getString("email_id"))).sendKeys(email);
		
	}
	
	public void enterPassword(String password) {
		
		driver.findElement(By.id(element.getString("password_id"))).sendKeys(password); 
	}
	
	
	public void clickSignInBtn() {
		
		driver.findElement(By.id(element.getString("signInBtnSubmit"))).click();
		
	}
	
}
