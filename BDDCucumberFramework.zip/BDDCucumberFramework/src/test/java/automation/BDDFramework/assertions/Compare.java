package automation.BDDFramework.assertions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Compare {

	//making them static means we can call them by their classname (Compare), no need to create an object
	public static boolean validatePageURL(WebDriver driver, String expectedURL) {
		
		
		boolean result = false;
		if(driver.getCurrentUrl().equalsIgnoreCase(expectedURL)) {
			
			result=true;
		}
		
		return result;
	}
	
	public static boolean validateElementExists(WebDriver driver, String element) {
		
		boolean result = false;
		
		try 
		{
		driver.findElement(By.id(element));
			
			result = true;
		}
		catch(Exception e)
		{}
		return result;
		}
		
	}
	