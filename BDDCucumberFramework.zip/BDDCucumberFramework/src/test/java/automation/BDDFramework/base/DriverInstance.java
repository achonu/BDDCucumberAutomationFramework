package automation.BDDFramework.base;

import java.util.ResourceBundle;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

//This class has methods to open and quit the browser, 
// depending on what browser name is in the config file

public class DriverInstance { // creates the instance
	
	WebDriver driver; // global driver
	
	public WebDriver createDriverInstance() {
		
		ResourceBundle config = ResourceBundle.getBundle("config"); // Create an object of the config file created
		if(config.getString("browser").equalsIgnoreCase("chrome")) {
			
			
			System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver");
			
			driver = new ChromeDriver();
		}
		
		else {
			
			System.setProperty("webdriver.gecko.driver", "./Drivers/geckodriver");
			driver = new FirefoxDriver();
		}
		
		driver.get(config.getString("website"));
				
			return driver; // return the object of the WebDriver value

	}
	
	public void closeDriverInstance(WebDriver driver) //passes the webdriver object first 
	{
		
		driver.quit();
	}

}
